window.toggleSidebar = () => {
    const sb = document.getElementById('sidebar');
    const bd = document.getElementById('sidebarBackdrop');
    if (sb && bd) {
        if(sb.classList.contains('-translate-x-full')) {
            sb.classList.remove('-translate-x-full');
            bd.classList.remove('hidden');
        } else {
            sb.classList.add('-translate-x-full');
            bd.classList.add('hidden');
        }
    }
};
