export const formatPrice = (price) => `₹${Number(price).toLocaleString('en-IN')}`;

export const formatDate = (ts) => {
    if(!ts) return 'N/A';
    const d = new Date(ts);
    return d.toLocaleDateString('en-IN', {
        day: 'numeric', 
        month: 'short', 
        year: 'numeric', 
        hour: '2-digit', 
        minute:'2-digit'
    });
};

export const processImageUrl = (url) => {
    if (!url) return ''; 
    try {
        if (url.includes('drive.google.com')) {
            let fileId = '';
            const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
            if (match && match[1]) fileId = match[1];
            else {
                const urlObj = new URL(url);
                fileId = urlObj.searchParams.get('id');
            }
            if (fileId) return `https://lh3.googleusercontent.com/d/${fileId}=w1000`;
        }
    } catch (e) { 
        console.error('Error parsing URL', e); 
    }
    return url; 
};
