window.showToast = (message, type = 'success') => {
    const toast = document.getElementById('toast');
    if (!toast) return;

    document.getElementById('toastMessage').innerText = message;
    document.getElementById('toastIcon').className = type === 'success' 
        ? 'fa-solid fa-circle-check text-green-400' 
        : 'fa-solid fa-circle-exclamation text-accent-red';
    
    toast.classList.remove('show');
    
    // Small delay to allow the DOM to register the class removal for animation
    setTimeout(() => {
        toast.classList.add('show');
        if(window._adminToastTimer) clearTimeout(window._adminToastTimer);
        window._adminToastTimer = setTimeout(() => { 
            toast.classList.remove('show'); 
        }, 3000);
    }, 10);
};
