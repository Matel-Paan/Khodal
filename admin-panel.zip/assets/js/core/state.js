export const State = {
    orders: [],
    products: [],
    categories: [], 
    banners: [],
    smallBanners: [],
    primaryBanners: [],
    affiliates: [],
    payouts: [],
    settings: {}
};

export const COMMISSION_RATE = 0.10; 

export const AppGlobals = {
    adminUser: null,
    currentActiveView: 'dashboard',
    currentProcessingPayoutId: null
};
