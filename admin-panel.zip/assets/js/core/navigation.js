import { AppGlobals } from './state.js';

export const refreshActiveView = () => {
    const view = AppGlobals.currentActiveView;
    
    if (view === 'dashboard' && window.initDashboard) window.initDashboard();
    else if (view === 'orders' && window.renderOrdersTable) window.renderOrdersTable();
    else if (view === 'affiliates' && window.renderAffiliates) window.renderAffiliates();
    else if (view === 'payouts' && window.renderPayouts) window.renderPayouts();
    else if (view === 'categories' && window.renderCategoriesTable) window.renderCategoriesTable();
    else if (view === 'settings' && window.renderSettings) window.renderSettings();
    else if (view === 'coupons' && window.renderCouponsTable) window.renderCouponsTable();
    else if (view === 'banners') {
        if(window.renderMainBannersTable) window.renderMainBannersTable();
        if(window.renderSmallBannersTable) window.renderSmallBannersTable();
        if(window.renderPrimaryBannersTable) window.renderPrimaryBannersTable();
    }
};

window.navigate = (target) => {
    AppGlobals.currentActiveView = target;
    
    if(window.innerWidth < 768 && window.toggleSidebar) {
        window.toggleSidebar();
    }
    
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.className = "nav-btn w-full flex items-center justify-between px-4 py-3 rounded-xl text-gray-400 hover:bg-white/5 hover:text-white font-semibold transition text-sm";
        if(btn.dataset.target === target) {
            btn.className = "nav-btn w-full flex items-center justify-between px-4 py-3 rounded-xl bg-white/10 text-white font-semibold transition text-sm";
        }
    });
    
    const titles = { 
        dashboard: 'Dashboard', 
        orders: 'Order Fulfillment', 
        products: 'Product Catalog', 
        categories: 'Store Categories', 
        banners: 'Storefront Banners', 
        affiliates: 'Partner Directory', 
        payouts: 'Payout Operations',
        coupons: 'Coupon Management',
        settings: 'Configuration' 
    };
    
    const headerTitle = document.getElementById('headerTitle');
    if (headerTitle) {
        headerTitle.innerText = titles[target] || 'Admin';
    }
    
    document.querySelectorAll('.admin-section').forEach(sec => sec.classList.remove('active'));
    const activeSec = document.getElementById(`sec-${target}`);
    if(activeSec) activeSec.classList.add('active');

    refreshActiveView();
    
    if (target === 'products' && window.renderProductsTable) {
        window.renderProductsTable();
    }
};
