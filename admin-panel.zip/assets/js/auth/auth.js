import { signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-auth.js";
import { auth } from "../config/firebase.js";
import { AppGlobals } from "../core/state.js";
import { setupRealtimeListeners } from "../database/listeners.js";

export const initAuth = () => {
    onAuthStateChanged(auth, async (user) => {
        const authView = document.getElementById('authView');
        const appView = document.getElementById('appView');
        const adminEmailDisplay = document.getElementById('adminEmailDisplay');

        if (user) {
            AppGlobals.adminUser = user;
            if (authView) authView.classList.add('hidden');
            if (appView) appView.classList.remove('hidden');
            if (adminEmailDisplay) adminEmailDisplay.innerText = user.email;
            
            // Safe initialization of listeners
            setupRealtimeListeners(); 
        } else {
            AppGlobals.adminUser = null;
            if (authView) authView.classList.remove('hidden');
            if (appView) appView.classList.add('hidden');
        }
    });

    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('btnLogin');
            const originalText = btn.innerHTML;
            btn.innerHTML = `<div class="loader border-white border-t-transparent mx-auto"></div>`;
            
            try {
                await signInWithEmailAndPassword(
                    auth, 
                    document.getElementById('loginEmail').value, 
                    document.getElementById('loginPassword').value
                );
                if (window.showToast) window.showToast('Authentication Successful');
            } catch (error) {
                if (window.showToast) window.showToast("Invalid Admin Credentials", 'error');
                btn.innerHTML = originalText;
            }
        });
    }
};

window.logoutAdmin = async () => {
    try {
        await signOut(auth);
        if (window.showToast) window.showToast('Session Terminated');
        setTimeout(() => window.location.reload(), 1000); 
    } catch (error) {
        console.error("Logout error", error);
    }
};
