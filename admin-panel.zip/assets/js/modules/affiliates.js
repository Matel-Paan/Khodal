import { State, COMMISSION_RATE } from "../core/state.js";
import { formatPrice } from "../core/helpers.js";

window.renderAffiliates = () => {
    const tbody = document.getElementById('affiliatesTableBody');
    if (!tbody) return;
    
    if(State.affiliates.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="px-6 py-16 text-center text-gray-500 font-medium">No registered affiliates found.</td></tr>`;
        return;
    }

    const affStats = State.affiliates.map(aff => {
        let totalRefs = 0, pending = 0, approved = 0;
        State.orders.forEach(o => {
            if(o.affiliateCode === aff.affiliateCode) {
                totalRefs++;
                let commStatus = o.commissionStatus;
                if(!commStatus) {
                    if (o.status === 'DELIVERED') commStatus = 'APPROVED';
                    else if (o.status === 'CANCELLED' || o.status === 'RETURNED') commStatus = 'REJECTED';
                    else commStatus = 'PENDING';
                }
                const commAmt = Number(o.commissionAmount || (Number(o.totalAmount || 0) * (o.commissionRate || COMMISSION_RATE)));
                if(commStatus === 'PENDING') pending += commAmt;
                if(commStatus === 'APPROVED') approved += commAmt;
            }
        });
        return { ...aff, totalRefs, pending, approved };
    });

    tbody.innerHTML = affStats.map(aff => {
        const st = aff.status === 'ACTIVE' 
            ? `<span class="bg-green-50 text-green-600 px-2 py-1 rounded text-[10px] font-bold uppercase border border-green-100">Active</span>` 
            : `<span class="bg-gray-100 text-gray-600 px-2 py-1 rounded text-[10px] font-bold uppercase">Inactive</span>`;
            
        return `
        <tr class="hover:bg-gray-50 transition border-b border-gray-50 last:border-0">
            <td class="px-6 py-4">
                <p class="font-bold text-accent-dark text-sm tracking-tight">${aff.name}</p>
                <p class="text-[10px] font-bold text-brand-600 uppercase tracking-widest mt-1"><i class="fa-solid fa-link mr-1"></i> ${aff.affiliateCode}</p>
            </td>
            <td class="px-6 py-4">
                <p class="text-xs font-bold text-gray-700">${aff.email}</p>
                <p class="text-[10px] text-gray-500 uppercase tracking-widest mt-1">${aff.phone || 'No Phone'}</p>
            </td>
            <td class="px-6 py-4 font-bold text-gray-900">${aff.totalRefs}</td>
            <td class="px-6 py-4 font-display font-bold text-orange-500">${formatPrice(aff.pending)}</td>
            <td class="px-6 py-4 font-display font-bold text-green-600">${formatPrice(aff.approved)}</td>
            <td class="px-6 py-4">${st}</td>
        </tr>`;
    }).join('');
};
