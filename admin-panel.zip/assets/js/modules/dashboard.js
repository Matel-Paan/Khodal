import { State, COMMISSION_RATE } from "../core/state.js";
import { formatPrice, formatDate } from "../core/helpers.js";

let salesChartInstance;

window.initDashboard = async () => {
    let revenue = 0;
    let pendingComm = 0;
    let pendingOrders = 0;
    
    State.orders.forEach(o => {
        const amt = Number(o.totalAmount || 0);
        if(o.status !== 'CANCELLED' && o.status !== 'RETURNED') revenue += amt;
        
        if(['NEW', 'CONFIRMED', 'PROCESSING'].includes(o.status)) pendingOrders++;
        
        let commStatus = o.commissionStatus;
        if(!commStatus) {
            if (o.status === 'DELIVERED') commStatus = 'APPROVED';
            else if (o.status === 'CANCELLED' || o.status === 'RETURNED') commStatus = 'REJECTED';
            else commStatus = 'PENDING';
        }
        if(commStatus === 'PENDING') {
            const rate = o.commissionRate || COMMISSION_RATE;
            pendingComm += Number(o.commissionAmount || (amt * rate));
        }
    });

    const kpiRevenue = document.getElementById('kpiRevenue');
    if (kpiRevenue) kpiRevenue.innerText = formatPrice(revenue);
    
    const kpiOrders = document.getElementById('kpiOrders');
    if (kpiOrders) kpiOrders.innerText = State.orders.length;
    
    const kpiAffiliates = document.getElementById('kpiAffiliates');
    if (kpiAffiliates) kpiAffiliates.innerText = State.affiliates.length;
    
    const kpiPendingComm = document.getElementById('kpiPendingComm');
    if (kpiPendingComm) kpiPendingComm.innerText = formatPrice(pendingComm);
    
    const badge = document.getElementById('badgePendingOrders');
    if(badge) badge.innerText = pendingOrders;

    const recent = [...State.orders].sort((a,b) => new Date(b.createdAt || b.date || 0) - new Date(a.createdAt || a.date || 0)).slice(0, 5);

    const statusColors = { 
        'NEW': 'bg-blue-50 text-blue-700', 
        'PROCESSING': 'bg-orange-50 text-orange-700', 
        'DELIVERED': 'bg-green-50 text-green-700', 
        'CANCELLED': 'bg-red-50 text-red-700' 
    };

    const recentOrdersList = document.getElementById('recentOrdersList');
    if (recentOrdersList) {
        recentOrdersList.innerHTML = recent.map(o => {
            const sc = statusColors[o.status] || 'bg-gray-100 text-gray-700';
            return `
            <div class="flex justify-between items-center p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-gray-200 transition">
                <div>
                    <p class="text-sm font-bold text-accent-dark tracking-tight">${o.orderId || o.id}</p>
                    <p class="text-[10px] text-gray-500 uppercase tracking-widest mt-1">${o.customerName || 'Unknown'} • ${formatDate(o.createdAt || o.date)}</p>
                </div>
                <div class="text-right">
                    <p class="text-sm font-bold text-accent-dark mb-1">${formatPrice(o.totalAmount)}</p>
                    <span class="text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-widest ${sc}">${o.status || 'NEW'}</span>
                </div>
            </div>
        `}).join('');
    }

    renderSalesChart();
};

const renderSalesChart = () => {
    const canvas = document.getElementById('salesChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if(salesChartInstance) salesChartInstance.destroy();
    
    const last7Days = Array.from({length: 7}, (_, i) => {
        const d = new Date(); d.setDate(d.getDate() - i); return d.toISOString().split('T')[0];
    }).reverse();

    const revenueMap = {};
    last7Days.forEach(d => revenueMap[d] = 0);

    State.orders.forEach(o => {
        if(o.status === 'CANCELLED' || o.status === 'RETURNED') return;
        const dateStr = new Date(o.createdAt || o.date || 0).toISOString().split('T')[0];
        if(revenueMap[dateStr] !== undefined) revenueMap[dateStr] += Number(o.totalAmount || 0);
    });

    if (typeof Chart !== 'undefined') {
        salesChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: last7Days.map(d => new Date(d).toLocaleDateString('en-US', {weekday: 'short', month: 'short', day:'numeric'})),
                datasets: [{
                    label: 'Gross Revenue (₹)', 
                    data: last7Days.map(d => revenueMap[d]),
                    borderColor: '#020617', 
                    backgroundColor: 'rgba(2, 6, 23, 0.05)', 
                    borderWidth: 2, 
                    tension: 0.3, 
                    fill: true, 
                    pointBackgroundColor: '#fff', 
                    pointBorderColor: '#020617', 
                    pointRadius: 4
                }]
            },
            options: { 
                responsive: true, 
                maintainAspectRatio: false, 
                plugins: { legend: { display: false } }, 
                scales: { 
                    y: { beginAtZero: true, grid: { borderDash: [4, 4], color: '#f1f5f9' } }, 
                    x: { grid: { display: false } } 
                } 
            }
        });
    }
};
