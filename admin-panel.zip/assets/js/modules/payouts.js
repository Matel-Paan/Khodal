import { State } from "../core/state.js";
import { formatPrice } from "../core/helpers.js";

window.renderPayouts = () => {
    const tbodyReq = document.getElementById('payoutsProcessingTable');
    const tbodyHist = document.getElementById('payoutHistoryTable');
    if (!tbodyReq || !tbodyHist) return;
    
    let requestedTotal = 0;
    const requests = State.payouts.filter(p => p.status === 'REQUESTED');
    const history = State.payouts.filter(p => p.status === 'PAID' || p.status === 'REJECTED');

    requests.forEach(r => requestedTotal += Number(r.amount));

    const totalRequiredPayouts = document.getElementById('totalRequiredPayouts');
    if (totalRequiredPayouts) {
        totalRequiredPayouts.innerText = formatPrice(requestedTotal);
    }

    if(requests.length === 0) {
        tbodyReq.innerHTML = `<tr><td colspan="4" class="px-6 py-10 text-center text-gray-500 font-medium">No pending payout requests!</td></tr>`;
    } else {
        tbodyReq.innerHTML = requests.map(req => {
            const affName = State.affiliates.find(a => a.id === req.affiliateId)?.name || 'Unknown';
            const d = req.createdAt ? new Date(req.createdAt).toLocaleDateString('en-IN') : 'N/A';
            return `
            <tr class="hover:bg-gray-50 transition border-b border-gray-50 last:border-0">
                <td class="px-6 py-4 text-xs font-bold text-gray-500">${d}</td>
                <td class="px-6 py-4"><p class="font-bold text-accent-dark">${affName}</p><p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">CODE: ${req.affiliateCode}</p></td>
                <td class="px-6 py-4 font-display font-bold text-orange-500 text-lg">${formatPrice(req.amount)}</td>
                <td class="px-6 py-4 text-right">
                    <button onclick="window.openProcessPayoutModal('${req.id}')" class="bg-accent-dark text-white px-5 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-widest shadow-md hover:bg-gray-800 transition">Review & Pay</button>
                </td>
            </tr>`;
        }).join('');
    }

    if(history.length === 0) {
        tbodyHist.innerHTML = `<tr><td colspan="5" class="px-6 py-10 text-center text-gray-500 font-medium">No historical payouts found.</td></tr>`;
    } else {
        const sortedHistory = [...history].sort((a,b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
        tbodyHist.innerHTML = sortedHistory.map(p => {
            const d = p.createdAt ? new Date(p.createdAt).toLocaleDateString('en-IN') : 'N/A';
            const affName = State.affiliates.find(a => a.id === p.affiliateId)?.name || 'Unknown';
            const statusClass = p.status === 'PAID' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-red-50 text-red-600 border-red-100';
            return `
            <tr class="hover:bg-gray-50 transition border-b border-gray-50 last:border-0">
                <td class="px-6 py-4 text-xs font-bold text-gray-700">${d}</td>
                <td class="px-6 py-4 text-sm font-bold text-accent-dark">${affName}</td>
                <td class="px-6 py-4 text-[10px] font-bold text-gray-500 uppercase tracking-widest">${p.transactionReference || 'N/A'}</td>
                <td class="px-6 py-4 font-display font-bold text-accent-dark">${formatPrice(p.amount)}</td>
                <td class="px-6 py-4"><span class="px-2 py-1 rounded text-[10px] font-bold uppercase border ${statusClass}">${p.status}</span></td>
            </tr>`;
        }).join('');
    }
};
