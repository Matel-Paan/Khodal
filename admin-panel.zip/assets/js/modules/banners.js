import { State } from "../core/state.js";
import { processImageUrl } from "../core/helpers.js";
import { deleteBannerDb } from "../database/banners-db.js";

const generateBannerRow = (b, type) => `
    <tr class="hover:bg-gray-50 transition border-b border-gray-50 last:border-0">
        <td class="px-6 py-4">
            <img src="${processImageUrl(b.imageUrl)}" class="w-32 h-16 rounded-lg object-cover bg-gray-100 border border-gray-200 shadow-sm">
        </td>
        <td class="px-6 py-4">
            <span class="font-bold text-gray-700 tracking-tight text-sm">${b.targetLink || 'shop'}</span>
        </td>
        <td class="px-6 py-4 text-right space-x-2">
            <button onclick="window.deleteBanner('${b.id}', '${type}')" class="w-8 h-8 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition inline-flex items-center justify-center"><i class="fa-solid fa-trash text-xs"></i></button>
        </td>
    </tr>
`;

window.renderMainBannersTable = () => {
    const tbody = document.getElementById('mainBannersTableBody');
    if (!tbody) return;
    if(State.banners.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="px-6 py-10 text-center text-gray-500 font-medium">No main banners found. Add your first banner.</td></tr>`;
        return;
    }
    tbody.innerHTML = State.banners.map(b => generateBannerRow(b, 'main')).join('');
};

window.renderSmallBannersTable = () => {
    const tbody = document.getElementById('smallBannersTableBody');
    if (!tbody) return;
    if(State.smallBanners.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="px-6 py-10 text-center text-gray-500 font-medium">No small banners found.</td></tr>`;
        return;
    }
    tbody.innerHTML = State.smallBanners.map(b => generateBannerRow(b, 'small')).join('');
};

window.renderPrimaryBannersTable = () => {
    const tbody = document.getElementById('primaryBannersTableBody');
    if (!tbody) return;
    if(State.primaryBanners.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="px-6 py-10 text-center text-gray-500 font-medium">No primary banners found.</td></tr>`;
        return;
    }
    tbody.innerHTML = State.primaryBanners.map(b => generateBannerRow(b, 'primary')).join('');
};

window.deleteBanner = async (id, type) => {
    if(!confirm(`Delete this ${type} banner? It will be removed from the Storefront immediately.`)) return;
    
    let dbNode = 'banners';
    if(type === 'small') dbNode = 'smallBanners';
    if(type === 'primary') dbNode = 'primaryBanners';
    
    try {
        await deleteBannerDb(dbNode, id);
        if (window.showToast) window.showToast('Banner Deleted');
    } catch(e) {
        if (window.showToast) window.showToast('Error removing banner', 'error');
    }
};
