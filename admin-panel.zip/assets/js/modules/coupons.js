import { State } from "../core/state.js";
import { db } from "../config/firebase.js";
import { ref, push, update, remove, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";

window.openCouponModal = () => {
    document.getElementById('couponForm').reset();
    document.getElementById('couponId').value = '';
    document.getElementById('couponModalTitle').innerText = 'Create Coupon';
    
    const modal = document.getElementById('couponModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.closeCouponModal = () => {
    const modal = document.getElementById('couponModal');
    modal.style.opacity = '0';
    setTimeout(() => { 
        modal.classList.add('hidden'); 
        modal.classList.remove('flex'); 
    }, 300);
};

window.editCoupon = (id) => {
    const c = State.coupons.find(x => x.id === id);
    if(!c) return;
    
    document.getElementById('couponId').value = c.id;
    document.getElementById('couponCode').value = c.code || '';
    document.getElementById('couponDiscount').value = c.discount || '';
    document.getElementById('couponMinOrder').value = c.minOrder || '';
    document.getElementById('couponProductId').value = c.productId || '';
    document.getElementById('couponDesc').value = c.description || '';
    
    document.getElementById('couponModalTitle').innerText = 'Edit Coupon';
    const modal = document.getElementById('couponModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.saveCoupon = async () => {
    const form = document.getElementById('couponForm');
    if(!form.checkValidity()) { form.reportValidity(); return; }

    const btn = document.getElementById('btnSaveCoupon');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<div class="loader w-4 h-4 border-white"></div>`;
    btn.disabled = true;

    try {
        const couponData = {
            code: document.getElementById('couponCode').value.toUpperCase().trim(),
            discount: Number(document.getElementById('couponDiscount').value),
            minOrder: Number(document.getElementById('couponMinOrder').value),
            productId: document.getElementById('couponProductId').value,
            description: document.getElementById('couponDesc').value.trim()
        };

        const id = document.getElementById('couponId').value;
        if(id) {
            couponData.updatedAt = serverTimestamp();
            await update(ref(db, `coupons/${id}`), couponData);
            if (window.showToast) window.showToast('Coupon Updated Successfully');
        } else {
            couponData.createdAt = serverTimestamp();
            await push(ref(db, 'coupons'), couponData);
            if (window.showToast) window.showToast('New Coupon Added');
        }
        window.closeCouponModal();
    } catch(e) {
        console.error(e);
        if (window.showToast) window.showToast('Failed to save coupon', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
};

window.deleteCoupon = async (id) => {
    if(confirm('Are you sure you want to delete this coupon?')) {
        try {
            await remove(ref(db, `coupons/${id}`));
            if (window.showToast) window.showToast('Coupon Deleted Successfully');
        } catch(e) {
            console.error(e);
            if (window.showToast) window.showToast('Error deleting coupon', 'error');
        }
    }
};

window.renderCouponsTable = () => {
    const tableBody = document.getElementById('couponsTableBody');
    if (!tableBody) return;

    if (!State.coupons || State.coupons.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" class="px-6 py-12 text-center text-gray-500 font-medium">
                    <div class="flex flex-col items-center justify-center">
                        <i class="fa-solid fa-ticket text-4xl mb-4 text-gray-300"></i>
                        <p>No coupons generated yet.</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    tableBody.innerHTML = State.coupons.map(c => {
        const linkedProduct = State.products.find(p => p.id === c.productId);
        const prodName = linkedProduct ? linkedProduct.name : 'Unknown Product';
        
        return `
            <tr class="hover:bg-gray-50 transition border-b border-gray-100">
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex flex-col">
                        <span class="text-sm font-bold text-accent-dark tracking-widest bg-brand-50 px-2 py-1 rounded inline-block w-fit uppercase">${c.code}</span>
                        <span class="text-[10px] text-gray-500 mt-1 truncate max-w-[200px]">${c.description}</span>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-green-600">
                    ${c.discount}% OFF
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-xs text-gray-600 truncate max-w-[150px]">
                    ${prodName}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-semibold">
                    ₹${c.minOrder}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onclick="editCoupon('${c.id}')" class="text-blue-500 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 w-8 h-8 rounded-lg inline-flex items-center justify-center transition mr-2">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button onclick="deleteCoupon('${c.id}')" class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 w-8 h-8 rounded-lg inline-flex items-center justify-center transition">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
};
