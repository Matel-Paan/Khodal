import { State } from "../core/state.js";
import { formatPrice, formatDate } from "../core/helpers.js";
import { updateOrderStatusDb } from "../database/orders-db.js";

window.renderOrdersTable = () => {
    const filterSelect = document.getElementById('orderFilterStatus');
    if (!filterSelect) return;
    
    const filter = filterSelect.value;
    let filtered = filter === 'ALL' 
        ? State.orders 
        : State.orders.filter(o => o.status === filter);
        
    filtered.sort((a,b) => new Date(b.createdAt || b.date || 0) - new Date(a.createdAt || a.date || 0));

    const tbody = document.getElementById('ordersTableBody');
    if (!tbody) return;

    if(filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="px-6 py-16 text-center text-gray-500 font-medium">No orders found matching criteria.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(o => {
        const statusColors = { 
            'NEW': 'bg-blue-50 text-blue-700', 
            'CONFIRMED': 'bg-blue-50 text-blue-700', 
            'PROCESSING': 'bg-orange-50 text-orange-700', 
            'READY_FOR_QIKINK': 'bg-indigo-50 text-indigo-700', 
            'SHIPPED': 'bg-purple-50 text-purple-700', 
            'DELIVERED': 'bg-green-100 text-green-700', 
            'CANCELLED': 'bg-red-50 text-red-700' 
        };
        const sc = statusColors[o.status] || 'bg-gray-100 text-gray-700';
        
        const affTag = o.affiliateCode 
            ? `<span class="bg-brand-50 text-brand-600 px-2 py-1 rounded text-[10px] font-bold uppercase border border-brand-100"><i class="fa-solid fa-link mr-1"></i> ${o.affiliateCode}</span>` 
            : `<span class="text-[10px] text-gray-400 uppercase tracking-widest">Direct Sale</span>`;
            
        const isOnline = o.paymentMethod === 'ONLINE';
        const utrTag = isOnline 
            ? `<p class="text-[10px] font-bold text-blue-600 uppercase tracking-widest mt-1">UTR: ${o.utrNumber || 'N/A'}</p>` 
            : '';

        return `
        <tr class="hover:bg-gray-50 transition border-b border-gray-50 last:border-0">
            <td class="px-6 py-4">
                <p class="font-bold text-accent-dark tracking-tight">${o.orderId || o.id}</p>
                <p class="text-[10px] text-gray-400 uppercase tracking-widest mt-1">${formatDate(o.createdAt || o.date)}</p>
            </td>
            <td class="px-6 py-4">
                <p class="font-bold text-accent-dark text-xs uppercase tracking-tight">${o.customerName || 'N/A'}</p>
                <p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">${o.mobile || 'N/A'}</p>
            </td>
            <td class="px-6 py-4">
                <p class="font-display font-bold text-accent-dark">${formatPrice(o.totalAmount)}</p>
                <p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">${o.paymentMethod || 'COD'}</p>
                ${utrTag}
            </td>
            <td class="px-6 py-4">${affTag}</td>
            <td class="px-6 py-4"><span class="px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest rounded-md ${sc}">${o.status || 'NEW'}</span></td>
            <td class="px-6 py-4 text-right">
                <div class="flex items-center justify-end gap-2">
                    <button onclick="viewOrderDetails('${o.id}')" class="w-9 h-9 rounded-lg bg-brand-50 text-brand-600 hover:bg-brand-100 transition inline-flex items-center justify-center shrink-0" title="View Full Details"><i class="fa-solid fa-eye text-xs"></i></button>
                    <select onchange="window.updateOrderStatus('${o.id}', this.value)" class="text-[10px] font-bold uppercase tracking-widest border border-gray-200 bg-white rounded-lg px-3 py-2 outline-none focus:border-accent-dark text-accent-dark cursor-pointer shadow-sm hover:bg-gray-50 transition">
                        <option value="">Update Status...</option>
                        <option value="CONFIRMED">Confirm Order</option>
                        <option value="PROCESSING">Processing</option>
                        <option value="READY_FOR_QIKINK">Ready (Qikink)</option>
                        <option value="SHIPPED">Shipped</option>
                        <option value="DELIVERED">Delivered</option>
                        <option value="CANCELLED">Cancel Order</option>
                    </select>
                </div>
            </td>
        </tr>`;
    }).join('');
};

window.updateOrderStatus = async (docId, newStatus) => {
    if(!newStatus) return;
    try {
        await updateOrderStatusDb(docId, newStatus);
        if (window.showToast) window.showToast(`Order status updated to ${newStatus}`);
    } catch(e) {
        console.error(e);
        if (window.showToast) window.showToast('Write Error: Database issue.', 'error');
    }
};
