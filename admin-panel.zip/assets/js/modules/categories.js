import { State } from "../core/state.js";
import { processImageUrl } from "../core/helpers.js";
import { deleteCategoryDb } from "../database/categories-db.js";

window.renderCategoriesTable = () => {
    const tbody = document.getElementById('categoriesTableBody');
    if (!tbody) return;
    
    if(State.categories.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" class="px-6 py-16 text-center text-gray-500 font-medium">No categories found. Create one.</td></tr>`;
        return;
    }
    
    tbody.innerHTML = State.categories.map(c => `
        <tr class="hover:bg-gray-50 transition border-b border-gray-50 last:border-0">
            <td class="px-6 py-4">
                <img src="${processImageUrl(c.image)}" class="w-16 h-16 rounded-xl object-cover bg-gray-100 border border-gray-200 shadow-sm">
            </td>
            <td class="px-6 py-4">
                <span class="font-bold text-accent-dark uppercase tracking-tight text-sm">${c.name}</span>
            </td>
            <td class="px-6 py-4 text-right space-x-2">
                <button onclick="window.deleteCategory('${c.id}')" class="w-8 h-8 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition inline-flex items-center justify-center"><i class="fa-solid fa-trash text-xs"></i></button>
            </td>
        </tr>
    `).join('');
};

window.deleteCategory = async (id) => {
    if(!confirm("Delete this category? It will be removed from the User Store immediately.")) return;
    try {
        await deleteCategoryDb(id);
        if (window.showToast) window.showToast('Category Deleted');
    } catch(e) {
        if (window.showToast) window.showToast('Error removing category', 'error');
    }
};
