import { State } from "../core/state.js";
import { processImageUrl } from "../core/helpers.js";
import { updatePaymentQRSettingsDb } from "../database/settings-db.js";

window.renderSettings = () => {
    const urlInput = document.getElementById('settingsQrUrl');
    const preview = document.getElementById('settingsQrPreview');
    const emptyState = document.getElementById('settingsQrEmpty');
    
    if(!urlInput) return;

    const qrUrl = State.settings.paymentQR || '';
    urlInput.value = qrUrl;

    if(qrUrl) {
        preview.src = processImageUrl(qrUrl);
        preview.classList.remove('hidden');
        emptyState.classList.add('hidden');
    } else {
        preview.classList.add('hidden');
        emptyState.classList.remove('hidden');
    }
};

window.saveSettings = async () => {
    const urlInput = document.getElementById('settingsQrUrl');
    if (!urlInput) return;
    
    const rawUrl = urlInput.value.trim();
    if(!rawUrl) { 
        if (window.showToast) window.showToast('Please paste a Google Drive QR link first', 'error'); 
        return; 
    }

    const btn = document.getElementById('btnSaveSettings');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<div class="loader w-4 h-4 border-white"></div>`;
    btn.disabled = true;

    try {
        const finalUrl = processImageUrl(rawUrl);
        await updatePaymentQRSettingsDb(finalUrl);
        if (window.showToast) window.showToast('Payment QR Code Updated Successfully');
    } catch(e) {
        console.error(e);
        if (window.showToast) window.showToast('Write Permission Denied.', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
};
