import { State } from "../core/state.js";
import { processImageUrl, formatPrice } from "../core/helpers.js";
import { addProductDb, updateProductDb, deleteProductDb } from "../database/products-db.js";

window.addProductImageInput = (value = '') => {
    const val = typeof value === 'string' ? value : '';
    const container = document.getElementById('dynamicImageInputs');
    if (!container) return;
    
    const inputDiv = document.createElement('div');
    inputDiv.className = 'flex gap-2 items-center';
    inputDiv.innerHTML = `
        <input type="url" name="prodImageUrls[]" value="${val}" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">
        <button type="button" onclick="this.parentElement.remove()" class="w-12 h-12 shrink-0 bg-red-50 text-red-500 rounded-xl hover:bg-red-100 transition flex items-center justify-center"><i class="fa-solid fa-trash"></i></button>
    `;
    container.appendChild(inputDiv);
};

window.openProductModal = () => {
    document.getElementById('productForm').reset();
    document.getElementById('prodId').value = '';
    if (window.populateProductCategories) window.populateProductCategories('');
    
    const dynamicInputs = document.getElementById('dynamicImageInputs');
    if (dynamicInputs) {
        dynamicInputs.innerHTML = `<input type="url" name="prodImageUrls[]" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">`;
    }
    
    document.getElementById('prodModalTitle').innerText = 'Add New Product';
    
    const modal = document.getElementById('productModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.closeProductModal = () => {
    const modal = document.getElementById('productModal');
    modal.style.opacity = '0';
    setTimeout(() => { 
        modal.classList.add('hidden'); 
        modal.classList.remove('flex'); 
    }, 300);
};

window.editProduct = (id) => {
    const p = State.products.find(x => x.id === id);
    if(!p) return;
    
    document.getElementById('prodId').value = p.id;
    document.getElementById('prodName').value = p.name || '';
    document.getElementById('prodPrice').value = p.price || '';
    document.getElementById('prodSalePrice').value = p.salePrice || '';
    if (window.populateProductCategories) window.populateProductCategories(p.category || '');
    document.getElementById('prodTags').value = (p.tags || []).join(', ');
    document.getElementById('prodSizes').value = (p.sizes || []).join(', ');
    document.getElementById('prodCouponCode').value = p.couponCode || ''; 
    document.getElementById('prodMaterial').value = p.material || '';
    document.getElementById('prodDescription').value = p.description || '';
    
    let imagesArray = [];
    if(p.images && Array.isArray(p.images) && p.images.length > 0) {
        imagesArray = p.images;
    } else if (p.images && typeof p.images === 'object') {
        imagesArray = Object.values(p.images);
    } else if (p.image) {
        imagesArray = [p.image];
    }

    const imgContainer = document.getElementById('dynamicImageInputs');
    if (imgContainer) {
        imgContainer.innerHTML = '';
        if(imagesArray.length === 0) {
            imgContainer.innerHTML = `<input type="url" name="prodImageUrls[]" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">`;
        } else {
            imagesArray.forEach((img, i) => {
                if(i === 0) {
                    imgContainer.innerHTML = `<input type="url" name="prodImageUrls[]" value="${img}" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">`;
                } else {
                    window.addProductImageInput(img);
                }
            });
        }
    }
    
    document.getElementById('prodModalTitle').innerText = 'Edit Product';
    const modal = document.getElementById('productModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.saveProduct = async () => {
    const form = document.getElementById('productForm');
    if(!form.checkValidity()) { form.reportValidity(); return; }

    const btn = document.getElementById('btnSaveProduct');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<div class="loader w-4 h-4 border-white"></div> Saving...`;
    btn.disabled = true;

    try {
        const inputs = document.querySelectorAll('input[name="prodImageUrls[]"]');
        let rawUrls = [];
        inputs.forEach(inp => {
            if(inp.value.trim()) rawUrls.push(inp.value.trim());
        });
        let finalImages = rawUrls.map(url => processImageUrl(url)); 
        let mainImage = finalImages.length > 0 ? finalImages[0] : '';

        const productData = {
            name: document.getElementById('prodName').value,
            price: Number(document.getElementById('prodPrice').value),
            salePrice: document.getElementById('prodSalePrice').value ? Number(document.getElementById('prodSalePrice').value) : null,
            category: document.getElementById('prodCategory').value,
            tags: document.getElementById('prodTags').value.split(',').map(t => t.trim()).filter(t=>t),
            sizes: document.getElementById('prodSizes').value.split(',').map(s => s.trim()).filter(s=>s),
            couponCode: document.getElementById('prodCouponCode').value.trim(), 
            material: document.getElementById('prodMaterial').value,
            description: document.getElementById('prodDescription').value,
            image: mainImage,
            images: finalImages
        };

        const id = document.getElementById('prodId').value;
        if(id) {
            await updateProductDb(id, productData);
            if (window.showToast) window.showToast('Product Updated Successfully');
        } else {
            await addProductDb(productData);
            if (window.showToast) window.showToast('New Product Added Successfully');
        }
        window.closeProductModal();
    } catch(e) {
        console.error(e);
        if (window.showToast) window.showToast('Write Permission Denied.', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
};

window.deleteProduct = async (id) => {
    if(confirm('Are you sure you want to delete this product?')) {
        try {
            await deleteProductDb(id);
            if (window.showToast) window.showToast('Product Deleted Successfully');
        } catch(e) {
            console.error(e);
            if (window.showToast) window.showToast('Error deleting product', 'error');
        }
    }
};

window.searchProducts = (query) => {
    window.renderProductsTable(query);
};

window.renderProductsTable = (searchQuery = '') => {
    const tableBody = document.getElementById('productsTableBody');
    if (!tableBody) return;

    let filteredProducts = State.products || [];
    
    if (searchQuery) {
        const query = searchQuery.toLowerCase();
        filteredProducts = filteredProducts.filter(p => 
            (p.name && p.name.toLowerCase().includes(query)) || 
            (p.category && p.category.toLowerCase().includes(query)) ||
            (p.tags && p.tags.join(' ').toLowerCase().includes(query))
        );
    }

    if (filteredProducts.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" class="px-6 py-12 text-center text-gray-500 font-medium">
                    <div class="flex flex-col items-center justify-center">
                        <i class="fa-solid fa-box-open text-4xl mb-4 text-gray-300"></i>
                        <p>No products found in the catalog.</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    tableBody.innerHTML = filteredProducts.map(p => {
        const priceDisplay = p.salePrice ? 
            `<span class="font-bold text-accent-dark">${formatPrice(p.salePrice)}</span> <span class="text-xs text-gray-400 line-through ml-1">${formatPrice(p.price)}</span>` : 
            `<span class="font-bold text-accent-dark">${formatPrice(p.price)}</span>`;

        const couponBadge = p.couponCode ? 
            `<span class="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded ml-2 uppercase tracking-widest border border-green-200"><i class="fa-solid fa-tag mr-1"></i>${p.couponCode}</span>` : 
            '';

        return `
            <tr class="hover:bg-gray-50 transition border-b border-gray-100">
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <div class="flex-shrink-0 h-12 w-12 bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
                            <img class="h-12 w-12 object-cover" src="${p.image || ''}" alt="">
                        </div>
                        <div class="ml-4">
                            <div class="text-sm font-bold text-accent-dark flex items-center">
                                <span class="truncate max-w-[200px] block">${p.name}</span>
                                ${couponBadge}
                            </div>
                            <div class="text-xs text-gray-500 uppercase tracking-widest mt-0.5">${p.category}</div>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    ${priceDisplay}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex flex-wrap gap-1 max-w-[150px]">
                        ${(p.sizes || []).map(s => `<span class="px-2 py-0.5 inline-flex text-[10px] leading-5 font-bold rounded bg-gray-100 text-gray-600 border border-gray-200">${s}</span>`).join('')}
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div class="flex flex-wrap gap-1 max-w-[150px]">
                        ${(p.tags || []).map(t => `<span class="px-2 py-0.5 inline-flex text-[10px] leading-5 font-bold rounded-full bg-brand-50 text-brand-600 border border-brand-100 uppercase tracking-widest">${t}</span>`).join('')}
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onclick="editProduct('${p.id}')" class="text-blue-500 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 w-8 h-8 rounded-lg inline-flex items-center justify-center transition mr-2">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button onclick="deleteProduct('${p.id}')" class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 w-8 h-8 rounded-lg inline-flex items-center justify-center transition">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
};

// Initial render if we are on the products page
if (document.getElementById('productsTableBody')) {
    window.renderProductsTable();
}