// Import Authentication Initializer
import { initAuth } from "./auth/auth.js";

// Import Modules for global window binding (Side-effects)
import "./core/navigation.js";
import "./core/sidebar.js";
import "./core/toast.js";

import "./modules/dashboard.js";
import "./modules/orders.js";
import "./modules/products.js";
import "./modules/categories.js";
import "./modules/banners.js";
import "./modules/affiliates.js";
import "./modules/payouts.js";
import "./modules/settings.js";

import "./components/product-modal.js";
import "./components/category-modal.js";
import "./components/banner-modal.js";
import "./components/payout-modal.js";

const loadHTML = async (url) => {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to load ${url}`);
        return await response.text();
    } catch (error) {
        console.error(`Component Loading Error:`, error);
        return '';
    }
};

const bootstrapApplication = async () => {
    const components = [
        { path: 'components/auth.html', target: 'auth-container' },
        { path: 'components/sidebar.html', target: 'sidebar-container' },
        { path: 'components/header.html', target: 'header-container' },
        { path: 'components/toast.html', target: 'toast-container' }
    ];

    const modals = [
        'components/modals/product-modal.html',
        'components/modals/category-modal.html',
        'components/modals/banner-modal.html',
        'components/modals/payout-modal.html'
    ];

    // 1. Load Primary Layout Components
    for (const comp of components) {
        const targetElement = document.getElementById(comp.target);
        if (targetElement) {
            targetElement.innerHTML = await loadHTML(comp.path);
        }
    }

    // 2. Load and Append Modals to Modals Container
    const modalsContainer = document.getElementById('modals-container');
    if (modalsContainer) {
        let modalsHTML = '';
        for (const modalPath of modals) {
            modalsHTML += await loadHTML(modalPath);
        }
        modalsContainer.innerHTML = modalsHTML;
    }

    // 3. Initialize Authentication (This automatically sets up Firebase listeners once authenticated)
    // We do this AFTER the DOM is built so elements like loginForm exist.
    initAuth();
};

// Bootstrap once the DOM is ready
document.addEventListener('DOMContentLoaded', bootstrapApplication);
