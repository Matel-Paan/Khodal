import { ref, push, remove, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";

export const addBannerDb = async (dbNode, bannerData) => {
    bannerData.createdAt = serverTimestamp();
    return await push(ref(db, dbNode), bannerData);
};

export const deleteBannerDb = async (dbNode, id) => {
    return await remove(ref(db, `${dbNode}/${id}`));
};
