// Affiliates are primarily managed by the user storefront.
// Realtime listeners in listeners.js handle synchronization.
// This file is reserved for future admin affiliate database mutations.

export const initAffiliatesDb = () => {
    // Reserved for future use (e.g., blocking or updating affiliate profiles directly from admin)
};
