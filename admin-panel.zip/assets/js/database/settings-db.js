import { ref, update, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";

export const updatePaymentQRSettingsDb = async (finalUrl) => {
    return await update(ref(db, 'settings'), { 
        paymentQR: finalUrl, 
        updatedAt: serverTimestamp() 
    });
};
