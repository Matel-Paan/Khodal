import { ref, onValue } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";
import { State, AppGlobals } from "../core/state.js";
import { refreshActiveView } from "../core/navigation.js";

let listenersInitialized = false;

// Helper to pre-load from sessionStorage for instant admin panel rendering
const loadFromSessionCache = (key, stateVar, renderCallback) => {
    const cached = sessionStorage.getItem(`admin_cache_${key}`);
    if (cached) {
        try {
            State[stateVar] = JSON.parse(cached);
            if (renderCallback) renderCallback();
        } catch (e) {}
    }
};

const updateSessionCache = (key, data) => {
    sessionStorage.setItem(`admin_cache_${key}`, JSON.stringify(data));
};

export const setupRealtimeListeners = () => {
    if (listenersInitialized) return; 
    listenersInitialized = true;

    // Categories
    loadFromSessionCache('categories', 'categories', () => {
        if (window.populateProductCategories) window.populateProductCategories();
        if (AppGlobals.currentActiveView === 'categories' && window.renderCategoriesTable) window.renderCategoriesTable();
    });
    onValue(ref(db, 'categories'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.categories = arr;
        updateSessionCache('categories', arr);
        if (window.populateProductCategories) window.populateProductCategories();
        if (AppGlobals.currentActiveView === 'categories' && window.renderCategoriesTable) window.renderCategoriesTable();
    });

    // Coupons
    onValue(ref(db, 'coupons'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.coupons = arr || [];
        if (AppGlobals.currentActiveView === 'coupons' && window.renderCouponsTable) window.renderCouponsTable();
    });

    // Banners
    loadFromSessionCache('banners', 'banners', () => {
        if (AppGlobals.currentActiveView === 'banners' && window.renderMainBannersTable) window.renderMainBannersTable();
    });
    onValue(ref(db, 'banners'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.banners = arr;
        updateSessionCache('banners', arr);
        if (AppGlobals.currentActiveView === 'banners' && window.renderMainBannersTable) window.renderMainBannersTable();
    });

    onValue(ref(db, 'smallBanners'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.smallBanners = arr;
        if (AppGlobals.currentActiveView === 'banners' && window.renderSmallBannersTable) window.renderSmallBannersTable();
    });

    onValue(ref(db, 'primaryBanners'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.primaryBanners = arr;
        if (AppGlobals.currentActiveView === 'banners' && window.renderPrimaryBannersTable) window.renderPrimaryBannersTable();
    });

    // Orders (Highly volatile, no cache)
    onValue(ref(db, 'orders'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.orders = arr;
        refreshActiveView();
    });

    // Products
    loadFromSessionCache('products', 'products', () => {
        if (AppGlobals.currentActiveView === 'products' && window.renderProductsTable) window.renderProductsTable();
        if (AppGlobals.currentActiveView === 'dashboard' && window.initDashboard) window.initDashboard();
    });
    onValue(ref(db, 'products'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { 
            const data = child.val();
            let rawImages = data.images || [];
            if (!Array.isArray(rawImages)) rawImages = [];
            if (rawImages.length === 0 && data.image) rawImages = [data.image];

            arr.push({ 
                id: child.key,
                name: data.name,
                price: data.price,
                salePrice: data.salePrice,
                category: data.category,
                tags: data.tags,
                image: data.image,
                images: rawImages,
                sizes: data.sizes,
                couponCode: data.couponCode || "",
                material: data.material !== undefined ? data.material : "",
                description: data.description !== undefined ? data.description : ""
            }); 
        });
        State.products = arr;
        updateSessionCache('products', arr);
        if (AppGlobals.currentActiveView === 'products' && window.renderProductsTable) window.renderProductsTable();
        if (AppGlobals.currentActiveView === 'dashboard' && window.initDashboard) window.initDashboard();
        
        const couponProdSelect = document.getElementById('couponProductId');
        if(couponProdSelect) {
            couponProdSelect.innerHTML = `<option value="">Select a Product</option>` + 
                State.products.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
        }
    });

    // Affiliates
    onValue(ref(db, 'affiliates'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.affiliates = arr;
        if (AppGlobals.currentActiveView === 'affiliates' && window.renderAffiliates) window.renderAffiliates();
        if (AppGlobals.currentActiveView === 'dashboard' && window.initDashboard) window.initDashboard();
    });

    // Payouts
    onValue(ref(db, 'payouts'), (snapshot) => {
        const arr = [];
        snapshot.forEach(child => { arr.push({ id: child.key, ...child.val() }); });
        State.payouts = arr;
        if (AppGlobals.currentActiveView === 'payouts' && window.renderPayouts) window.renderPayouts();
    });

    // Settings
    onValue(ref(db, 'settings'), (snapshot) => {
        State.settings = snapshot.val() || {};
        if (AppGlobals.currentActiveView === 'settings' && window.renderSettings) window.renderSettings();
    });
};
