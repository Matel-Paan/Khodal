import { ref, update, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";

export const processPayoutDb = async (payoutId, txnId, adminEmail) => {
    const payoutData = { 
        status: 'PAID', 
        transactionReference: txnId, 
        processedAt: serverTimestamp(),
        processedBy: adminEmail || 'admin' 
    };
    return await update(ref(db, `payouts/${payoutId}`), payoutData);
};
