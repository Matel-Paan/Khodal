import { ref, update, push, remove, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";

export const addProductDb = async (productData) => {
    productData.createdAt = serverTimestamp();
    return await push(ref(db, 'products'), productData);
};

export const updateProductDb = async (id, productData) => {
    productData.updatedAt = serverTimestamp();
    return await update(ref(db, `products/${id}`), productData);
};

export const deleteProductDb = async (id) => {
    return await remove(ref(db, `products/${id}`));
};
