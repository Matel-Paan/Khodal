import { ref, push, remove, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";

export const addCategoryDb = async (catData) => {
    catData.createdAt = serverTimestamp();
    return await push(ref(db, 'categories'), catData);
};

export const deleteCategoryDb = async (id) => {
    return await remove(ref(db, `categories/${id}`));
};
