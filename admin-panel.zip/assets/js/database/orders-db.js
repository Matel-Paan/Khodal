import { ref, update, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";
import { db } from "../config/firebase.js";

export const updateOrderStatusDb = async (docId, newStatus) => {
    const updateData = { 
        status: newStatus, 
        updatedAt: serverTimestamp() 
    };
    
    if (newStatus === 'DELIVERED') {
        updateData.commissionStatus = 'APPROVED';
    }
    if (newStatus === 'CANCELLED' || newStatus === 'RETURNED') {
        updateData.commissionStatus = 'REJECTED';
    }
    
    return await update(ref(db, `orders/${docId}`), updateData);
};
