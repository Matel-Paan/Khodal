import { State, AppGlobals } from "../core/state.js";
import { formatPrice, processImageUrl } from "../core/helpers.js";
import { processPayoutDb } from "../database/payouts-db.js";

window.openProcessPayoutModal = (payoutId) => {
    AppGlobals.currentProcessingPayoutId = payoutId;
    
    const payout = State.payouts.find(p => p.id === payoutId);
    if (!payout) return;
    
    const affiliate = State.affiliates.find(a => a.id === payout.affiliateId);
    
    document.getElementById('popAffiliateName').innerText = affiliate?.name || 'Unknown';
    document.getElementById('popAmount').innerText = formatPrice(payout.amount);
    
    const pDetails = affiliate?.paymentDetails || {};
    const type = pDetails.type || 'NONE';
    
    const detailsDiv = document.getElementById('popPaymentDetails');
    
    if(type === 'UPI') {
        detailsDiv.innerHTML = `<p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Saved UPI ID</p><p class="font-bold text-xl text-accent-dark tracking-wide bg-gray-50 py-3 rounded-xl border border-gray-100 inline-block px-6">${pDetails.upiId}</p>`;
    } else if (type === 'QR') {
        detailsDiv.innerHTML = `<p class="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3">Saved QR Code</p><img src="${processImageUrl(pDetails.qrUrl)}" class="w-48 h-48 object-contain rounded-xl border border-gray-200 p-2 mx-auto">`;
    } else {
        detailsDiv.innerHTML = `<div class="bg-red-50 p-4 rounded-xl border border-red-100"><p class="text-xs font-bold text-red-500 uppercase tracking-widest"><i class="fa-solid fa-triangle-exclamation mr-2"></i>Affiliate has not set up payment details.</p></div>`;
    }
    
    document.getElementById('popTransactionId').value = '';
    
    const modal = document.getElementById('processPayoutModal');
    if (!modal) return;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.closeProcessPayoutModal = () => {
    const modal = document.getElementById('processPayoutModal');
    if (!modal) return;
    
    modal.style.opacity = '0';
    setTimeout(() => { 
        modal.classList.add('hidden'); 
        modal.classList.remove('flex'); 
    }, 300);
    AppGlobals.currentProcessingPayoutId = null;
};

window.confirmManualPayout = async () => {
    if(!AppGlobals.currentProcessingPayoutId) return;
    
    const txnId = document.getElementById('popTransactionId').value.trim();
    if(!txnId) {
        if (window.showToast) window.showToast("Please enter the Bank Transaction / UTR ID as proof.", "error");
        return;
    }

    const btn = document.getElementById('btnConfirmPayout');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<div class="loader w-4 h-4 border-white"></div> Processing...`;
    btn.disabled = true;

    try {
        const adminEmail = AppGlobals.adminUser?.email;
        await processPayoutDb(AppGlobals.currentProcessingPayoutId, txnId, adminEmail);
        
        if (window.showToast) window.showToast(`Payment recorded successfully!`);
        window.closeProcessPayoutModal();
    } catch (e) {
        console.error("Payout error", e);
        if (window.showToast) window.showToast("Error processing payment.", "error");
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
};
