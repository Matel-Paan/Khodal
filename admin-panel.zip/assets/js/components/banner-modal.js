import { processImageUrl } from "../core/helpers.js";
import { addBannerDb } from "../database/banners-db.js";

window.openBannerModal = (type) => {
    document.getElementById('bannerForm').reset();
    document.getElementById('bannerType').value = type;
    
    let title = 'Add Banner';
    let recText = '';
    
    if(type === 'main') {
        title = 'Add Main Banner';
        recText = 'Recommended Aspect Ratio: 1080 x 1800 (Vertical)';
    } else if (type === 'small') {
        title = 'Add Small Banner';
        recText = 'Recommended Size: 1200 x 400 (Wide)';
    } else if (type === 'primary') {
        title = 'Add Primary Banner';
        recText = 'Recommended Size: 1000 x 1500 (Vertical)';
    }

    document.getElementById('bannerModalTitle').innerText = title;
    document.getElementById('bannerSizeRec').innerText = recText;

    const modal = document.getElementById('bannerModal');
    if (!modal) return;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.closeBannerModal = () => {
    const modal = document.getElementById('bannerModal');
    if (!modal) return;
    
    modal.style.opacity = '0';
    setTimeout(() => { 
        modal.classList.add('hidden'); 
        modal.classList.remove('flex'); 
    }, 300);
};

window.saveBanner = async () => {
    const form = document.getElementById('bannerForm');
    if(!form.checkValidity()) { form.reportValidity(); return; }

    const btn = document.getElementById('btnSaveBanner');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<div class="loader w-4 h-4 border-white"></div>`;
    btn.disabled = true;

    const type = document.getElementById('bannerType').value;
    let dbNode = 'banners';
    if(type === 'small') dbNode = 'smallBanners';
    if(type === 'primary') dbNode = 'primaryBanners';

    try {
        let rawUrl = document.getElementById('bannerImageUrl').value;
        let finalImageUrl = processImageUrl(rawUrl); 

        const bannerData = {
            imageUrl: finalImageUrl,
            targetLink: document.getElementById('bannerTarget').value || 'shop'
        };

        await addBannerDb(dbNode, bannerData);
        if (window.showToast) {
            window.showToast(`${type.charAt(0).toUpperCase() + type.slice(1)} Banner Added Successfully`);
        }
        window.closeBannerModal();
    } catch(e) {
        console.error(e);
        if (window.showToast) window.showToast('Permission Denied.', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
};
