import { State } from "../core/state.js";
import { processImageUrl } from "../core/helpers.js";
import { addProductDb, updateProductDb } from "../database/products-db.js";

window.addProductImageInput = (value = '') => {
    const val = typeof value === 'string' ? value : '';
    const container = document.getElementById('dynamicImageInputs');
    if (!container) return;
    
    const inputDiv = document.createElement('div');
    inputDiv.className = 'flex gap-2 items-center';
    inputDiv.innerHTML = `
        <input type="url" name="prodImageUrls[]" value="${val}" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">
        <button type="button" onclick="this.parentElement.remove()" class="w-12 h-12 shrink-0 bg-red-50 text-red-500 rounded-xl hover:bg-red-100 transition flex items-center justify-center"><i class="fa-solid fa-trash"></i></button>
    `;
    container.appendChild(inputDiv);
};

// Fill the Category <select> from live categories (State.categories)
window.populateProductCategories = (selected = '') => {
    const select = document.getElementById('prodCategory');
    if (!select) return;

    const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const current = selected || select.value || '';
    const cats = State.categories || [];

    let html = '<option value="">Select a Category</option>';
    html += cats.map(c => `<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');

    // Keep old/deleted category selectable while editing an existing product
    if (current && !cats.some(c => c.name === current)) {
        html += `<option value="${esc(current)}">${esc(current)}</option>`;
    }

    select.innerHTML = html;
    select.value = current;
};

window.openProductModal = () => {
    document.getElementById('productForm').reset();
    document.getElementById('prodId').value = '';
    window.populateProductCategories('');
    
    const dynamicInputs = document.getElementById('dynamicImageInputs');
    if (dynamicInputs) {
        dynamicInputs.innerHTML = `<input type="url" name="prodImageUrls[]" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">`;
    }
    
    document.getElementById('prodModalTitle').innerText = 'Add New Product';
    
    const modal = document.getElementById('productModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.closeProductModal = () => {
    const modal = document.getElementById('productModal');
    modal.style.opacity = '0';
    setTimeout(() => { 
        modal.classList.add('hidden'); 
        modal.classList.remove('flex'); 
    }, 300);
};

window.editProduct = (id) => {
    const p = State.products.find(x => x.id === id);
    if(!p) return;
    
    document.getElementById('prodId').value = p.id;
    document.getElementById('prodName').value = p.name || '';
    document.getElementById('prodPrice').value = p.price || '';
    document.getElementById('prodSalePrice').value = p.salePrice || '';
    window.populateProductCategories(p.category || '');
    document.getElementById('prodTags').value = (p.tags || []).join(', ');
    document.getElementById('prodSizes').value = (p.sizes || []).join(', ');
    document.getElementById('prodCouponCode').value = p.couponCode || '';
    document.getElementById('prodMaterial').value = p.material || '';
    document.getElementById('prodDescription').value = p.description || '';
    
    let imagesArray = [];
    if(p.images && Array.isArray(p.images) && p.images.length > 0) {
        imagesArray = p.images;
    } else if (p.images && typeof p.images === 'object') {
        imagesArray = Object.values(p.images);
    } else if (p.image) {
        imagesArray = [p.image];
    }

    const imgContainer = document.getElementById('dynamicImageInputs');
    if (imgContainer) {
        imgContainer.innerHTML = '';
        if(imagesArray.length === 0) {
            imgContainer.innerHTML = `<input type="url" name="prodImageUrls[]" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">`;
        } else {
            imagesArray.forEach((img, i) => {
                if(i === 0) {
                    imgContainer.innerHTML = `<input type="url" name="prodImageUrls[]" value="${img}" placeholder="Paste Google Drive shareable link..." class="w-full bg-white border border-gray-200 rounded-xl px-5 py-4 font-medium focus:ring-2 focus:ring-accent-dark outline-none text-sm transition shadow-sm">`;
                } else {
                    window.addProductImageInput(img);
                }
            });
        }
    }
    
    document.getElementById('prodModalTitle').innerText = 'Edit Product';
    const modal = document.getElementById('productModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => modal.style.opacity = '1', 10);
};

window.saveProduct = async () => {
    const form = document.getElementById('productForm');
    if(!form.checkValidity()) { form.reportValidity(); return; }

    const btn = document.getElementById('btnSaveProduct');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<div class="loader w-4 h-4 border-white"></div> Saving...`;
    btn.disabled = true;

    try {
        const inputs = document.querySelectorAll('input[name="prodImageUrls[]"]');
        let rawUrls = [];
        inputs.forEach(inp => {
            if(inp.value.trim()) rawUrls.push(inp.value.trim());
        });
        let finalImages = rawUrls.map(url => processImageUrl(url)); 
        let mainImage = finalImages.length > 0 ? finalImages[0] : '';

        const productData = {
            name: document.getElementById('prodName').value,
            price: Number(document.getElementById('prodPrice').value),
            salePrice: document.getElementById('prodSalePrice').value ? Number(document.getElementById('prodSalePrice').value) : null,
            category: document.getElementById('prodCategory').value,
            tags: document.getElementById('prodTags').value.split(',').map(t => t.trim()).filter(t=>t),
            sizes: document.getElementById('prodSizes').value.split(',').map(s => s.trim()).filter(s=>s),
            couponCode: document.getElementById('prodCouponCode').value.trim(),
            material: document.getElementById('prodMaterial').value,
            description: document.getElementById('prodDescription').value,
            image: mainImage,
            images: finalImages
        };

        const id = document.getElementById('prodId').value;
        if(id) {
            await updateProductDb(id, productData);
            if (window.showToast) window.showToast('Product Updated Successfully');
        } else {
            await addProductDb(productData);
            if (window.showToast) window.showToast('New Product Added Successfully');
        }
        window.closeProductModal();
    } catch(e) {
        console.error(e);
        if (window.showToast) window.showToast('Write Permission Denied.', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
};
